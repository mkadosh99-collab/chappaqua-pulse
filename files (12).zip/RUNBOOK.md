# Deployment runbook — for Claude Code

You are running on the user's own machine, in the `chappaqua-pulse` repo. The user is
**new to deployment**. Explain each step in plain language *before* you run it, and stop
for confirmation before anything that costs money or is hard to undo.

Do not skip steps. Do not batch them. Verify each checkpoint before moving on.

---

## Step 1 — Confirm the working tree is ready

```bash
git status
git log --oneline -3
```

If `chappaqua-pulse-full.patch` has not been applied yet, apply it:

```bash
git apply chappaqua-pulse-full.patch
```

Confirm these files exist: `Dockerfile`, `.do/app.yaml`, `DEPLOY.md`,
`client/public/living-map.html`.

**Checkpoint:** `grep -c "package-firewall.replit.local" package-lock.json` must print `0`.
If it prints anything else, the Replit-internal package has come back and `npm ci` will
fail on DigitalOcean's builder. Remove `@replit/connectors-sdk` from `package.json` and
run `npm install --package-lock-only`.

## Step 2 — Prove the build works locally before paying for a server

```bash
npm ci
npm run build
```

Both must succeed. If `npm ci` fails, do not continue — the same failure will happen on
DigitalOcean, just slower and with a worse error message.

**Checkpoint:** `dist/index.cjs` and `dist/public/` both exist.

## Step 3 — Push to GitHub

App Platform deploys from GitHub, not from local files. Nothing you have not pushed will
be deployed.

```bash
git add -A
git commit -m "Town brand theme, rebuilt living map, deploy config"
git push
```

**Checkpoint:** ask the user to open their repo in a browser and confirm the commit is
visible. Do not take `git push` exiting 0 as sufficient — confirm visually.

## Step 4 — Set the admin password

`.do/app.yaml` contains the placeholder `REPLACE_WITH_A_LONG_RANDOM_STRING`.

```bash
openssl rand -base64 32
```

Replace the placeholder with that value. **Tell the user to save it in their password
manager now** — it is how they log into the admin page to approve merchant submissions,
and it is not recoverable from the app.

Do not commit the real password. Either set it in the DigitalOcean UI after deploy, or
commit only the placeholder and update the value in the dashboard.

## Step 5 — Install and authenticate doctl

```bash
# macOS
brew install doctl
# or see https://docs.digitalocean.com/reference/doctl/how-to/install/

doctl auth init
```

This needs a DigitalOcean API token. Walk the user through creating one:
cloud.digitalocean.com → API → Generate New Token → **read and write** scope.

They need a DigitalOcean account with a payment method first. **Stop and confirm they
have one before continuing.**

## Step 6 — Create the app (this starts billing)

**Confirm with the user before running this.** It creates a ~$12/mo app and a ~$7/mo
database, about **$19/month total**.

```bash
doctl apps create --spec .do/app.yaml
```

Watch the build:

```bash
doctl apps list
doctl apps logs <app-id> --type build --follow
```

First build takes 5–10 minutes.

**Checkpoint:** the app reports a live URL ending in `.ondigitalocean.app`. Open it. The
homepage and events should load. **The business directory will still be broken** — that is
expected and Step 7 fixes it.

## Step 7 — Create the database tables

This is the step that gets missed. The database exists but has no tables, so
`/api/businesses` returns 500 and the directory page is dead.

1. Add the user's IP to the database's trusted sources:
   cloud.digitalocean.com → Databases → `pulse-db` → Settings → Trusted Sources.
2. Copy the full connection string from Connection Details.
3. Run:

```bash
DATABASE_URL="<the connection string>" npm run db:push
```

Confirm when drizzle-kit asks about creating tables.

**Checkpoint:** reload the live site. The business directory must now load.

## Step 8 — Verify everything, not just the homepage

Check each one and report results to the user:

- [ ] Homepage loads with orange styling and Outfit headings
- [ ] This week's events show real listings
- [ ] Business directory loads (the Step 7 fix)
- [ ] `/living-map.html` opens; both Map and History tabs work
- [ ] Submit a test business through the form
- [ ] Log into admin with the Step 4 password and confirm the test submission appears
- [ ] Delete the test submission

## Step 9 — Domain

cloud.digitalocean.com → the app → Settings → Domains. Add `chappaquadaily.com` and
`www.chappaquadaily.com`. DigitalOcean returns DNS records; the user adds them at their
registrar. TLS certificates are automatic. Propagation: minutes to a few hours.

**Note:** `chappaquadaily.com` is already serving the previous version of this site from
somewhere. Find out where before repointing DNS, so the user knows what they are switching
away from and can switch back if needed.

---

## If something fails

Do not guess. Get the actual error:

```bash
doctl apps logs <app-id> --type build     # build failures
doctl apps logs <app-id> --type run       # crashes after deploy
```

Common causes, in order of likelihood:

1. `package-firewall.replit.local` back in the lockfile → Step 1 checkpoint
2. `DATABASE_URL` unset → the server throws at startup, container crash-loops
3. Tables not created → app runs, directory 500s (Step 7)
4. Wrong `http_port` → health checks fail, deploy rolls back. Must be 8080

## Do not

- Raise `instance_count` above 1. See the comment in `.do/app.yaml`.
- Move `PLACES` data out of `client/public/living-map.html`. Every shop's x/y is derived
  from its real street address; that placement work is not reproducible from the JSON.
- Commit the real `ADMIN_PASSWORD`.
