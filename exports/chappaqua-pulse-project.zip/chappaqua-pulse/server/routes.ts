import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { timingSafeEqual } from "crypto";
import { storage } from "./storage";
import { scrapeAllEvents } from "./scraper";
import { getChappaquaRestaurants, getRestaurantSpecials } from "./restaurant-data";
import { startOfWeek, endOfWeek, parseISO } from "date-fns";
import {
  insertBusinessSubmissionSchema,
  submissionStatuses,
  type SubmissionStatus,
  type DirectoryBusiness,
} from "@shared/schema";
import retailersData from "@shared/retailers.json";

function isAdminConfigured(): boolean {
  return typeof process.env.ADMIN_PASSWORD === "string" && process.env.ADMIN_PASSWORD.length > 0;
}

function checkAdminPassword(provided: string): boolean {
  const expected = process.env.ADMIN_PASSWORD;
  if (!expected) return false;
  const a = Buffer.from(provided);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (!isAdminConfigured()) {
    return res.status(503).json({ error: "Admin access is not configured yet." });
  }
  const header = req.header("x-admin-password") || "";
  if (!checkAdminPassword(header)) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}

let isInitialized = false;
let initializationPromise: Promise<void> | null = null;
let scheduledRefreshInterval: NodeJS.Timeout | null = null;

const REFRESH_INTERVAL_MS = 60 * 60 * 1000; // 1 hour

async function refreshData() {
  try {
    console.log(`[${new Date().toISOString()}] Scheduled refresh starting...`);
    
    const events = await scrapeAllEvents();
    await storage.clearEvents();
    await storage.createManyEvents(events);
    console.log(`[${new Date().toISOString()}] Refreshed ${events.length} events`);
    
    storage.setLastUpdated(new Date());
  } catch (error) {
    console.error(`[${new Date().toISOString()}] Scheduled refresh failed:`, error);
  }
}

function startScheduledRefresh() {
  if (scheduledRefreshInterval) {
    clearInterval(scheduledRefreshInterval);
  }
  
  scheduledRefreshInterval = setInterval(async () => {
    await refreshData();
  }, REFRESH_INTERVAL_MS);
  
  console.log(`Scheduled refresh started - will refresh every ${REFRESH_INTERVAL_MS / 1000 / 60} minutes`);
}

async function initializeData() {
  if (isInitialized) return;
  
  if (initializationPromise) {
    await initializationPromise;
    return;
  }
  
  initializationPromise = (async () => {
    try {
      console.log("Initializing data...");
      
      const events = await scrapeAllEvents();
      await storage.clearEvents();
      await storage.createManyEvents(events);
      console.log(`Loaded ${events.length} events`);
      
      const restaurantData = getChappaquaRestaurants();
      await storage.clearRestaurants();
      const createdRestaurants = await storage.createManyRestaurants(restaurantData);
      console.log(`Loaded ${createdRestaurants.length} restaurants`);
      
      const restaurantIds = new Map<string, string>();
      createdRestaurants.forEach((r) => restaurantIds.set(r.name, r.id));
      
      const specialsData = getRestaurantSpecials(restaurantIds);
      await storage.clearSpecials();
      await storage.createManySpecials(specialsData);
      console.log(`Loaded ${specialsData.length} specials`);
      
      storage.setLastUpdated(new Date());
      isInitialized = true;
      
      startScheduledRefresh();
    } catch (error) {
      console.error("Error initializing data:", error);
      throw error;
    }
  })();
  
  await initializationPromise;
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.get("/api/events", async (req, res) => {
    try {
      await initializeData();
      
      const weekStartParam = req.query.weekStart as string | undefined;
      const fromParam = req.query.from as string | undefined;
      const toParam = req.query.to as string | undefined;
      
      let weekStart: Date;
      let weekEnd: Date;
      
      // Arbitrary date range (used by the month calendar view)
      if (fromParam && toParam) {
        const from = parseISO(fromParam);
        const to = parseISO(toParam);
        if (!isNaN(from.getTime()) && !isNaN(to.getTime())) {
          // Guard against a reversed range
          weekStart = from <= to ? from : to;
          weekEnd = from <= to ? to : from;
        } else {
          weekStart = startOfWeek(new Date(), { weekStartsOn: 0 });
          weekEnd = endOfWeek(weekStart, { weekStartsOn: 0 });
        }
      } else {
        if (weekStartParam) {
          try {
            weekStart = parseISO(weekStartParam);
            if (isNaN(weekStart.getTime())) {
              weekStart = startOfWeek(new Date(), { weekStartsOn: 0 });
            }
          } catch {
            weekStart = startOfWeek(new Date(), { weekStartsOn: 0 });
          }
        } else {
          weekStart = startOfWeek(new Date(), { weekStartsOn: 0 });
        }
        weekEnd = endOfWeek(weekStart, { weekStartsOn: 0 });
      }
      
      const events = await storage.getEventsByWeek(weekStart, weekEnd);
      const lastUpdated = storage.getLastUpdated();
      
      res.json({
        events,
        lastUpdated: lastUpdated?.toISOString() || null,
        weekStart: weekStart.toISOString(),
        weekEnd: weekEnd.toISOString(),
      });
    } catch (error) {
      console.error("Error fetching events:", error);
      res.status(500).json({ 
        error: "Failed to fetch events",
        message: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.get("/api/restaurants", async (req, res) => {
    try {
      await initializeData();
      
      const restaurantsWithSpecials = await storage.getRestaurantsWithSpecials();
      const lastUpdated = storage.getLastUpdated();
      
      res.json({
        restaurants: restaurantsWithSpecials,
        lastUpdated: lastUpdated?.toISOString() || null,
      });
    } catch (error) {
      console.error("Error fetching restaurants:", error);
      res.status(500).json({ 
        error: "Failed to fetch restaurants",
        message: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.get("/api/specials", async (req, res) => {
    try {
      await initializeData();
      
      const typeParam = req.query.type as string | undefined;
      
      let specials;
      if (typeParam) {
        specials = await storage.getSpecialsByType(typeParam as any);
      } else {
        specials = await storage.getActiveSpecials();
      }
      
      const restaurants = await storage.getRestaurants();
      const restaurantMap = new Map(restaurants.map(r => [r.id, r.name]));
      
      const specialsWithRestaurant = specials.map(special => ({
        ...special,
        restaurantName: restaurantMap.get(special.restaurantId) || "Unknown",
      }));
      
      const lastUpdated = storage.getLastUpdated();
      
      res.json({
        specials: specialsWithRestaurant,
        lastUpdated: lastUpdated?.toISOString() || null,
      });
    } catch (error) {
      console.error("Error fetching specials:", error);
      res.status(500).json({ 
        error: "Failed to fetch specials",
        message: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.post("/api/refresh", async (req, res) => {
    try {
      console.log("Refreshing all data...");
      isInitialized = false;
      initializationPromise = null;
      await initializeData();
      
      res.json({
        success: true,
        lastUpdated: storage.getLastUpdated()?.toISOString(),
      });
    } catch (error) {
      console.error("Error refreshing data:", error);
      res.status(500).json({ 
        error: "Failed to refresh data",
        message: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.get("/api/health", (req, res) => {
    res.json({
      status: "ok",
      initialized: isInitialized,
      lastUpdated: storage.getLastUpdated()?.toISOString() || null,
    });
  });

  // Public directory: base retailers + approved submissions, merged.
  app.get("/api/businesses", async (req, res) => {
    try {
      const approved = await storage.getApprovedBusinessSubmissions();
      const approvedBusinesses: DirectoryBusiness[] = approved.map((s) => ({
        id: s.id,
        name: s.name,
        category: s.category,
        cluster: s.cluster || "",
        address: s.address,
        owner: s.owner || "",
      }));

      res.json({
        businesses: [...(retailersData as DirectoryBusiness[]), ...approvedBusinesses],
      });
    } catch (error) {
      console.error("Error fetching businesses:", error);
      res.status(500).json({
        error: "Failed to fetch businesses",
        message: error instanceof Error ? error.message : "Unknown error",
      });
    }
  });

  // Public submission endpoint.
  app.post("/api/business-submissions", async (req, res) => {
    try {
      const parsed = insertBusinessSubmissionSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({
          error: "Invalid submission",
          details: parsed.error.flatten().fieldErrors,
        });
      }

      const submission = await storage.createBusinessSubmission(parsed.data);
      res.status(201).json({ submission });
    } catch (error) {
      console.error("Error creating business submission:", error);
      res.status(500).json({
        error: "Failed to submit business",
        message: error instanceof Error ? error.message : "Unknown error",
      });
    }
  });

  // Admin: verify password.
  app.post("/api/admin/login", (req, res) => {
    if (!isAdminConfigured()) {
      return res.status(503).json({ error: "Admin access is not configured yet." });
    }
    const password = typeof req.body?.password === "string" ? req.body.password : "";
    if (!checkAdminPassword(password)) {
      return res.status(401).json({ error: "Incorrect password." });
    }
    res.json({ ok: true });
  });

  // Admin: list submissions (defaults to pending).
  app.get("/api/admin/submissions", requireAdmin, async (req, res) => {
    try {
      const statusParam = req.query.status as string | undefined;
      const status =
        statusParam && submissionStatuses.includes(statusParam as SubmissionStatus)
          ? (statusParam as SubmissionStatus)
          : "pending";
      const submissions = await storage.getBusinessSubmissions(status);
      res.json({ submissions });
    } catch (error) {
      console.error("Error fetching submissions:", error);
      res.status(500).json({
        error: "Failed to fetch submissions",
        message: error instanceof Error ? error.message : "Unknown error",
      });
    }
  });

  // Admin: approve or reject a submission.
  app.patch("/api/admin/submissions/:id", requireAdmin, async (req, res) => {
    try {
      const action = req.body?.action;
      if (action !== "approve" && action !== "reject") {
        return res.status(400).json({ error: "Action must be 'approve' or 'reject'." });
      }
      const status: SubmissionStatus = action === "approve" ? "approved" : "rejected";
      const updated = await storage.updateBusinessSubmissionStatus(req.params.id, status);
      if (!updated) {
        return res.status(404).json({ error: "Submission not found." });
      }
      res.json({ submission: updated });
    } catch (error) {
      console.error("Error updating submission:", error);
      res.status(500).json({
        error: "Failed to update submission",
        message: error instanceof Error ? error.message : "Unknown error",
      });
    }
  });

  return httpServer;
}
